@extends('layouts/pageHead')
<style>
    /* bootstrap links colors*/
    .pagination>li>a,
    .pagination>li>span {
        color: #4d4d4d;
    }

    .pagination>.active>a,
    .pagination>.active>a:focus,
    .pagination>.active>a:hover,
    .pagination>.active>span,
    .pagination>.active>span:focus,
    .pagination>.active>span:hover {
        background-color: #4d4d4d;
        border-color: #4d4d4d;
    }
</style>
<main class="marginTopSmallNavLong p-3" style="background-color:  #F5F5F5;">
    <div class="mx-auto m-2 wid80 wid20Mobile d-block higt125px" style="overflow: hidden;">
        <a href="{{ $bannerLong->url }}"><img src="{{ 'files/'.$bannerLong->name }}" class="wid100" alt=""></a>
    </div>
    <div class="d-block wid70 wid100Mobile mx-auto">
        <p class="fontSize24px boldSix ksbBlue">Blog</p>
        @foreach($newses as $news)
        <div class="d-flex flex-wrap p-2 bgWhite my-3">
            <div class="newsImage col-12 col-sm-4 me-sm-5 me-0">
                <img src="{{ 'files/'.$news->name }}" alt="" class="wid100">
            </div>
            <div class=" align-self-center col-11 col-sm-7">
                <p class="fontSize14px boldFour socialColorDeeperNine m-0 mt-2">{{ date('M d,Y', strtotime($news->created_at)) }}</p>
                <p class="fontSize20px boldFive socialColorDeeper m-0">{{ $news->newstitle }}</p>
                <p class="fontSize14px boldFour bodyA m-0 my-2">{{ substr($news->newsbody, 0, 90) }}...</p>
                <a href="/news/{{$news->id}}" class="bodyAA fontSize12px">Read more <img class="wid16px" src="{{ asset('icons/arrow.png') }}" alt=""></a>
            </div>
        </div>
        @endforeach
        <div class="wid40">{{ $newses->links() }}</div>
        <!-- <div class="d-flex flex-wrap p-2 bgWhite my-3">
            <div class="newsImage col-12 col-sm-4 me-sm-5 me-0">
                <img src="{{ asset('icons/shortBanner.jpg') }}" alt="" class="wid100">
            </div>
            <div class=" align-self-center col-11 col-sm-7">
                <p class="fontSize14px boldFour socialColorDeeperNine m-0 mt-2">October 12, 2024</p>
                <p class="fontSize20px boldFive socialColorDeeper m-0">Blog Post Title</p>
                <p class="fontSize14px boldFour bodyA m-0 my-2">Sed ut perspiciatis unde omnis iste natus error sit accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab ill...</p>
                <a href="/news" class="bodyA fontSize14px">Read more <img src="{{ asset('icons/arrow.png') }}" alt=""></a>
            </div>
        </div> -->
    </div>
    <!-- Modal markup -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <img src="{{ asset('icons/telegramModal.gif') }}" class="wid100 pointers" alt="Image" onclick="location.href='https://t.me/+qw-sNCIYYAc1MGI0'">
                </div>
            </div>
        </div>
    </div>

</main>
@extends('layouts/footer')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
<script>
    $(document).ready(function() {
        var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
        var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl)
        })

        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: '/loadHomeGames',
            type: 'GET',
            success: (data) => {
                $("#homeGames").html(data)
            }
        })



        // if (localStorage.getItem('myItem') !== null) {
        //     $('#imageModal').modal('hide');
        // } else {
        //     setTimeout(function() {
        //         $('#imageModal').modal('show');
        //         localStorage.setItem('myItem', 'myValue');
        //     }, 6000);
        // }
        // setTimeout(function() {
        //     localStorage.removeItem('myItem');
        // }, 120000);
    });
</script>