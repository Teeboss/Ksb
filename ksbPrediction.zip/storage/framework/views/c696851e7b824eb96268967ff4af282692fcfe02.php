
<main class="marginTopSmallNavLong p-3" style="background-color: #f5f5f5;">
    <div class=" wid40 wid100Mobile  rounded bgWhite p-4 mx-auto ">
        <p class="text-center fontSize20px boldFive">Recover your password</p>
        <p class="text-center fontSize10px boldFive">we'll send you a password reset pin to your registered email address.</p>
        <?php if(Session::has('successfor')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('successfor')); ?>

        </div>
        <?php endif; ?>
        <?php if(Session::has('noMail')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('noMail')); ?>

        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('forgot.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div id="errors-list-login"></div>
            <div class="my-4">
                <input type="email" name="email" placeholder="Email" class="form-control fontSize14px" id="">
                <?php if($errors->has('email')): ?>
                <span class="alert-danger"><?php echo e($error->first('email')); ?></span>
                <?php endif; ?>
            </div>
            <div class="my-4">
                <button type="submit" class="rounded-pill p-2 wid100 borderNone white boldSix fontSize18px bgBlueKsbTwo">Proceed</button>
            </div>

        </form>
        <a href="/recovery" class="fontSize12px"> Goto Recovery Page</a>
    </div>
</main>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-8FKKQNJ4Z8"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-8FKKQNJ4Z8');
</script>
<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts/pageHead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravelProjects\ksbPrediction\resources\views/forgot.blade.php ENDPATH**/ ?>