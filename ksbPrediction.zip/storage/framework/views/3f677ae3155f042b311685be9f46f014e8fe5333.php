<h2>Hey, It's me <?php echo e($data->name); ?></h2>
<br>

<strong>User details: </strong><br>
<strong>Email: </strong><?php echo e($data->email); ?> <br>
<strong>Subject: </strong><?php echo e($data->subject); ?> <br>
<strong>Message: </strong><?php echo e($data->message); ?> <br><br>

Thank you<?php /**PATH C:\laravelProjects\ksbPrediction\resources\views/emails/contact.blade.php ENDPATH**/ ?>