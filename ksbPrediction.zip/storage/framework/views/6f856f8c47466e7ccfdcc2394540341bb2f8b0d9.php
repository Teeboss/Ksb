
<main class="p-3 marginTopSmallNavLong" style="background-color: #f5f5f5;">
    <div class=" wid40 wid100Mobile  rounded bgWhite p-4 mx-auto ">
        <p class="text-center fontSize20px boldFive">Reset Password</p>
        <p class="text-center fontSize10px boldFive">You will now click on the login button</p>
        <?php if(Session::has('recovery')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('recovery')); ?>

        </div>
        <?php endif; ?>
        <?php if(Session::has('pinMsg')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('pinMsg')); ?>

        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('reset.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div id="errors-list-login"></div>
            <div class="my-4">
                <input type="text" name="pin" placeholder="Recovery Pin" class="form-control fontSize14px" id="">
                <?php if($errors->has('pin')): ?>
                <span class="alert-danger"><?php echo e($error->first('pin')); ?></span>
                <?php endif; ?>
            </div>
            <div class="my-4">
                <input type="password" name="password" placeholder="Insert Your new Password" class="form-control fontSize14px" id="">
                <?php if($errors->has('password')): ?>
                <span class="alert-danger"><?php echo e($error->first('password')); ?></span>
                <?php endif; ?>
            </div>
            <div class="my-4">
                <button type="submit" class="rounded-pill p-2 wid100 borderNone white boldSix fontSize18px bgBlueKsbTwo">Proceed</button>
            </div>

        </form>
    </div>
</main>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-8FKKQNJ4Z8"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-8FKKQNJ4Z8');
</script>
<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts/pageHead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravelProjects\ksbPrediction\resources\views/reset.blade.php ENDPATH**/ ?>