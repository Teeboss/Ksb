<main>
    <img src="<?php echo e(asset('icons/midIcon.png')); ?>" class=" mt-5 d-block mx-auto">
    <h2 class="text-center boldEight blackKsb ">Recovery Pin for <?php echo e($data->email); ?></h2>
    <br>

    <strong>Your Pin: </strong><?php echo e($data->pin); ?> <br>


    Thank you
</main><?php /**PATH C:\laravelProjects\ksbPrediction\resources\views/emails/forgot.blade.php ENDPATH**/ ?>