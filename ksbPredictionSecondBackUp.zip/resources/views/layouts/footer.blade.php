<footer class="bgBlueKsb wid100Mobile p-2">
    <div class="wid80 d-none d-lg-block pt-4 mx-auto">
        <div class="d-flex flex-wrap justify-content-between align-items-center">
            <img src="{{ asset('icons/iconHome.png') }}" alt="">
            <div class="d-flex justify-content-between">
                <p class="m-3 fontSize16px white boldFour">Contact Us</p>
                <img src="{{ asset('icons/beware.png') }}" class="m-3" alt="" style="height: 18px;">
                <p class="m-3 fontSize16px white boldFour">Terms & Conditions</p>
                <p class="m-3 fontSize16px white boldFour">Privacy Policy</p>
            </div>
            <div>
                <img src="{{ asset('icons/facebook.png') }}" class="m-2" alt="">
                <img src="{{ asset('icons/twitter.png') }}" class="m-2" alt="">
                <img src="{{ asset('icons/instagram.png') }}" class="m-2" alt="">
            </div>
        </div>
    </div>
    <p class="fontSize12px mt-4 shadeWhite text-center d-none d-lg-block">King Solomon Bet &copy; {{ date("Y") }}</p>
    <div class="d-block pt-2 wid20Mobile mx-auto d-sm-none">
        <img src="{{ asset('icons/iconNav.png')}}" alt="" class="d-block wid24px mx-auto">
        <div class="d-flex justify-content-center">
            <p class="m-3 fontSize10px white boldFour noWrap">Contact Us</p>
            <p class="m-3 fontSize10px white boldFour noWrap">Terms & Conditions</p>
            <p class="m-3 fontSize10px white boldFour noWrap">Privacy Policy</p>
        </div>
        <div class="d-flex justify-content-center align-items-center">
            <img src="{{ asset('icons/facebook.png') }}" class="m-2 wid9px" alt="">
            <img src="{{ asset('icons/twitter.png') }}" class="m-2 wid16px" alt="">
            <img src="{{ asset('icons/instagram.png') }}" class="m-2 wid16px" alt="">
        </div>
        <p class="fontSize12px mt-4 shadeWhite text-center d-block d-sm-none">King Solomon Bet &copy; {{ date("Y") }}</p>
    </div>
    <!-- <div class="absolute bgRed p-5 black" style="bottom: 0; z-index: 333; top: 324%; left: 300;">
        <div class="d-flex align-items-center">
            <img src="{{ asset('icons/facebook.png') }}" class="m-2 wid9px" alt="">
            <img src="{{ asset('icons/twitter.png') }}" class="m-2 wid9px" alt="">
            <img src="{{ asset('icons/instagram.png') }}" class="m-2 wid9px" alt="">
        </div>
    </div> -->
</footer>
</body>

</html>