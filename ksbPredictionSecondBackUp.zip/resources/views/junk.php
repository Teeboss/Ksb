@extends('layouts/pageHead')
<main class="marginTopSmallNavLong" style="background-color:  #F5F5F5;">
    <div class="mx-auto m-2 wid80 wid20Mobile d-block higt125px" style="overflow: hidden;">
        <img src="{{ asset('icons/1xbanner.png') }}" class="wid100" alt="">
    </div>
    <div class="d-block p-2 p-sm-0 mx-auto wid100Mobile wid50 bgWhite">
        <p class="white fontSize12px boldFive wid100 bgShaddyWhite p-2"><img src="{{ asset('icons/football/england.png') }}" class="me-2" alt=""> England | EFL Cup</p>
        <div class="wid100 p-2">
            <div class="d-block bgSocials wid100 mx-auto mt-5">
                <div class="d-flex p-2 justify-content-center align-items-center">
                    <div class="d-flex align-items-center"><!-- width will help with the flex spacing -->
                        <span class="fontSize24px socialColorDeeper boldFive centerText">Man.Utd</span>
                        <div class="d-flex align-items-center ms-2">
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingRed">L</span>
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGrey">D</span>
                        </div>
                    </div>
                    <span class="boldFour bodyA mx-4 fontSize12px">02:00</span>
                    <div class="d-flex align-items-center">
                        <div class="d-flex align-items-center me-3">
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGrey">D</span>
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingRed">L</span>
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                            <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGrey">D</span>
                        </div>
                        <span class="fontSize24px socialColorDeeper boldFive">Chalton</span>
                    </div>
                </div>
            </div>
            <div class="flex justify-content-center m-5">
                <span class="fontSize14px bodyA ms-3 boldFour">Prediction</span>
                <span class="fontSize14px socialColorDeeper ms-3 boldFive">GG</span>
                <span class="fontSize14px socialColorDeeper ms-3 boldFive">Both Team Score</span>
            </div>
            <p class="fontSize12px boldFive p-2 bgSocials socialColorDeeper">Head to Head</p>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
                    <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
                </div>
            </div>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
                    <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
                </div>
            </div>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
                    <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
                </div>
            </div>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
                    <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
                </div>
            </div>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
                    <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
                </div>
            </div>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
                    <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
                </div>
            </div>
        </div>
        <div class="wid100 bgSocials p-3">
            <p class="fontSize12px boldFive ">Bet on this match on</p>
            <div class="d-flex flex-wrap justify-content-between">
                <img src="{{ asset('icons/bookmarks/btway.png') }}" class="wid45px" alt="">
                <img src="{{ asset('icons/bookmarks/everygame.png') }}" class="wid45px" alt="">
                <img src="{{ asset('icons/bookmarks/22b.png') }}" class="wid45px" alt="">
                <img src="{{ asset('icons/bookmarks/1win.png') }}" class="wid45px" alt="">
                <img src="{{ asset('icons/bookmarks/1xb.png') }}" class="wid45px" alt="">
            </div>
        </div>
        <div class="bgWhite d-flex flex-wrap justify-content-between wid100 py-3 px-1 py-sm-5">
            <div class="wid45 wid100Mobile">
                <span class="fontSize12px d-block boldFive p-2 bgSocials socialColorDeeper">Man. Utd: Last results</span>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
            </div>
            <div class="wid45 wid100Mobile">
                <span class="fontSize12px d-block boldFive p-2 bgSocials socialColorDeeper">Chalton: Last results</span>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
            </div>
        </div>
        <div class="mx-auto m-0 wid100 wid20Mobile d-block higt125px" style="overflow: hidden;">
            <img src="{{ asset('icons/1xbanner.png') }}" class="wid100" alt="">
        </div>
    </div>
</main>
@extends('layouts/footer')

<div class="wid60 wid20Mobile d-block mx-auto">
    <div id="wg-api-football-standings" data-host="v3.football.api-sports.io" data-key="0126ec08b8msh9cb2066fb6d9415p1a063ajsn7b6be79b4e0f" data-league="<?php echo request()->leagueId; ?>" data-team="" data-season="<?php echo date('Y', strtotime("-1 year")); ?>" data-theme="" data-show-errors="false" data-show-logos="true" class="wg_loader">
    </div>
</div>















<span class='fontSize10px noWrap bodyA boldFour'>" . self::changeTimeZoneTwo($data->timezone, $data->date) . " </span>
<span class='fontSize12px socialColorDeeper noWrap boldFour'>" . $data->teams->home->name . "</span>
<span class='fontSize14px socialColorDeeper noWrap boldFive'> " . $data->scores->home->total . " : " . $data->scores->away->total . "</span>
<span class='fontSize12px noWrap socialColorDeeper boldFour'> " . $data->teams->away->name . "</span>












<!-- <p>Fixture Datas inside fixtureData Id</p> -->

<p class="white fontSize12px boldFive wid100 bgShaddyWhite p-2"><img src="{{ asset('icons/football/england.png') }}" class="me-2" alt=""> England | EFL Cup</p>
<div class="wid100 p-2">
    <div class="d-block bgSocials wid100 mx-auto mt-5">
        <div class="d-block wid100Mobile wid70 mx-auto">
            <div class="d-flex p-2 justify-content-between align-items-center">
                <div class="d-flex align-items-center"><!-- width will help with the flex spacing -->
                    <span class="fontSize24px noWrap socialColorDeeper boldFive centerText">Man.Utd</span>
                    <div class="d-lg-flex align-items-center ms-2 d-none">
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingRed">L</span>
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGrey">D</span>
                    </div>
                </div>
                <span class="boldFour bodyA mx-4 fontSize12px">02:00</span>
                <div class="d-flex align-items-center">
                    <div class="d-lg-flex align-items-center me-3  d-none">
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGrey">D</span>
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingRed">L</span>
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGrey">D</span>
                    </div>
                    <span class="fontSize24px noWrap socialColorDeeper boldFive">Chalton</span>
                </div>
            </div>
        </div>
    </div>
    <div class="flex justify-content-center m-5">
        <span class="fontSize14px bodyA ms-3 boldFour">Prediction</span>
        <span class="fontSize14px socialColorDeeper ms-3 boldFive">GG</span>
        <span class="fontSize14px socialColorDeeper ms-3 boldFive">Both Team Score</span>
    </div>
    <p class="fontSize12px boldFive p-2 bgSocials socialColorDeeper">Head to Head</p>
    <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
        <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
            <span class="fontSize10px bodyA boldFour">06.01.2023</span>
            <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
            <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
            <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
        </div>
    </div>
    <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
        <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
            <span class="fontSize10px bodyA boldFour">06.01.2023</span>
            <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
            <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
            <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
        </div>
    </div>
    <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
        <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
            <span class="fontSize10px bodyA boldFour">06.01.2023</span>
            <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
            <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
            <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
        </div>
    </div>
    <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
        <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
            <span class="fontSize10px bodyA boldFour">06.01.2023</span>
            <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
            <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
            <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
        </div>
    </div>
    <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
        <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
            <span class="fontSize10px bodyA boldFour">06.01.2023</span>
            <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
            <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
            <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
        </div>
    </div>
    <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
        <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
            <span class="fontSize10px bodyA boldFour">06.01.2023</span>
            <span class="fontSize12px socialColorDeeper boldFour">Man.utd</span>
            <span class="fontSize14px socialColorDeeper boldFive">1 : 0</span>
            <span class="fontSize12px socialColorDeeper boldFour">Chalton</span>
        </div>
    </div>
</div>
<div class="wid100 bgSocials p-3">
    <p class="fontSize12px boldFive ">Bet on this match on</p>
    <div class="d-flex flex-wrap justify-content-between">
        <img src="{{ asset('icons/bookmarks/btway.png') }}" class="wid45px" alt="">
        <img src="{{ asset('icons/bookmarks/everygame.png') }}" class="wid45px" alt="">
        <img src="{{ asset('icons/bookmarks/22b.png') }}" class="wid45px" alt="">
        <img src="{{ asset('icons/bookmarks/1win.png') }}" class="wid45px" alt="">
        <img src="{{ asset('icons/bookmarks/1xb.png') }}" class="wid45px" alt="">
    </div>
</div>
<div class="bgWhite d-flex flex-wrap justify-content-between wid100 py-3 px-1 py-sm-5">
    <div class="wid45 wid100Mobile">
        <span class="fontSize12px d-block boldFive p-2 bgSocials socialColorDeeper">Man. Utd: Last results</span>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Man.Utd N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
    </div>
    <div class="wid45 wid100Mobile">
        <span class="fontSize12px d-block boldFive p-2 bgSocials socialColorDeeper">Chalton: Last results</span>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
        <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
            <div class="d-flex align-items-center">
                <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                <span class="blackKsbTwo fontSize10px noWrap">Chalton N Forest</span>
            </div>
            <span class="fontSize10px blackKsbTwo">4:1</span>
        </div>
    </div>
</div>








"
<div class='d-block wid100 rounded-pill p-2 m-1 shadow-sm'>
    <div class='ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile'>
        <span class='fontSize10px bodyA boldFour'>06.01.2023</span>
        <span class='fontSize12px socialColorDeeper boldFour'>" . $data->teams->home->name . "</span>
        <span class='fontSize14px socialColorDeeper boldFive'>" . $data->goals->home . " : " . $data->goals->away . "</span>
        <span class='fontSize12px socialColorDeeper boldFour'>" . $data->teams->away->name . "</span>
    </div>
</div>
"

<!-- Basketball Datas form the basketball fixture page  -->
@extends('layouts/pageHead')
<main class="marginTopSmallNavLong" style="background-color:  #F5F5F5;">
    <div class="mx-auto m-2 wid80 wid20Mobile d-block higt125px" style="overflow: hidden;">
        <img src="{{ asset('icons/1xbanner.png') }}" class="wid100" alt="">
    </div>
    <div class="d-block p-2 p-sm-0 mx-auto wid100Mobile wid50 bgWhite" id="fixtureData">
        <p class="white fontSize12px boldFive wid100 bgShaddyWhite p-2"><img src="{{ asset('icons/football/spain.png') }}" class="me-2" alt=""> spain: Leb Plata</p>
        <div class="wid100 p-2">
            <div class="d-block bgSocials wid100 mx-auto mt-5">
                <div class="d-block wid100Mobile wid70 mx-auto">
                    <div class="d-flex p-2 justify-content-between align-items-center">
                        <div class="d-flex align-items-center"><!-- width will help with the flex spacing -->
                            <span class="fontSize24px noWrap socialColorDeeper boldFive centerText">Zornotza ST</span>
                            <div class="d-lg-flex align-items-center ms-2 d-none">
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingRed">L</span>
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGrey">D</span>
                            </div>
                        </div>
                        <span class="boldFour bodyA mx-4 fontSize12px">02:00</span>
                        <div class="d-flex align-items-center">
                            <div class="d-lg-flex align-items-center me-3  d-none">
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGrey">D</span>
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingRed">L</span>
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGreen">W</span>
                                <span class="fontSize6px marginRightStandings padSmall1 borderRA1 white boldFive standingGrey">D</span>
                            </div>
                            <span class="fontSize24px noWrap socialColorDeeper boldFive">Navarra</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex justify-content-center m-5">
                <span class="fontSize14px bodyA ms-3 boldFour">Prediction</span>
                <span class="fontSize14px socialColorDeeper ms-3 boldFive">293</span>
                <span class="fontSize14px socialColorDeeper ms-3 boldFive">Home win</span>
            </div>
            <p class="fontSize12px boldFive p-2 bgSocials socialColorDeeper">Head to Head</p>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Zornotza ST</span>
                    <span class="fontSize14px socialColorDeeper boldFive">87 : 77</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Navarra</span>
                </div>
            </div>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Navarra</span>
                    <span class="fontSize14px socialColorDeeper boldFive">70 : 92</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Zornotza ST</span>
                </div>
            </div>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Navarra</span>
                    <span class="fontSize14px socialColorDeeper boldFive">79 : 71</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Zornotza ST</span>
                </div>
            </div>
            <div class="d-block wid100 rounded-pill p-2 m-1 shadow-sm">
                <div class="ms-3 ms-sm-5 d-flex justify-content-between align-items-center wid40 wid30Mobile">
                    <span class="fontSize10px bodyA boldFour">06.01.2023</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Zornotza ST</span>
                    <span class="fontSize14px socialColorDeeper boldFive">83 : 88</span>
                    <span class="fontSize12px socialColorDeeper boldFour">Navarra</span>
                </div>
            </div>

        </div>
        <div class="wid100 bgSocials p-3">
            <p class="fontSize12px boldFive ">Bet on this match on</p>
            <div class="d-flex flex-wrap justify-content-between">
                <img src="{{ asset('icons/bookmarks/btway.png') }}" class="wid45px" alt="">
                <img src="{{ asset('icons/bookmarks/everygame.png') }}" class="wid45px" alt="">
                <img src="{{ asset('icons/bookmarks/22b.png') }}" class="wid45px" alt="">
                <img src="{{ asset('icons/bookmarks/1win.png') }}" class="wid45px" alt="">
                <img src="{{ asset('icons/bookmarks/1xb.png') }}" class="wid45px" alt="">
            </div>
        </div>
        <div class="bgWhite d-flex flex-wrap justify-content-between wid100 py-3 px-1 py-sm-5">
            <div class="wid45 wid100Mobile">
                <span class="fontSize12px d-block boldFive p-2 bgSocials socialColorDeeper">Zornotza ST: Last results</span>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Zornotza ST N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Zornotza ST N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Zornotza ST N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Zornotza ST N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Zornotza ST N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
            </div>
            <div class="wid45 wid100Mobile">
                <span class="fontSize12px d-block boldFive p-2 bgSocials socialColorDeeper">Chalton: Last results</span>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
                <div class="d-flex my-1 justify-content-between p-2 align-items-center shadow-sm">
                    <div class="d-flex align-items-center">
                        <span class="fontSize12px me-3 padSmall1 borderRA1 white boldFive standingGreen">W</span>
                        <span class="blackKsbTwo fontSize10px noWrap">Chalton N Navarra</span>
                    </div>
                    <span class="fontSize10px blackKsbTwo">4:1</span>
                </div>
            </div>
        </div>
        <div class="mx-auto m-0 wid100 wid20Mobile d-block higt125px" style="overflow: hidden;">
            <img src="{{ asset('icons/1xbanner.png') }}" class="wid100" alt="">
        </div>
        <div class=" wid100Mobile d-block mx-sm-auto" style="overflow: scroll;">
            <div id="wg-api-basketball-games" data-host="api-basketball.p.rapidapi.com" data-key="0126ec08b8msh9cb2066fb6d9415p1a063ajsn7b6be79b4e0f" data-date="" data-league="12" data-season="2022" data-theme="" data-refresh="15" data-show-toolbar="true" data-show-errors="false" data-show-logos="true" data-modal-game="true" data-modal-standings="true" data-modal-show-logos="true">
            </div>
        </div>
        <script type="module" src="https://widgets.api-sports.io/2.0.3/widgets.js">
        </script>

    </div>
</main>
@extends('layouts/footer')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
<script type="module" src="https://widgets.api-sports.io/2.0.3/widgets.js"></script>
<script>
    //  $(document).ready(function() {
    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: '/loadFixtureBasketball/' + <?php echo request()->fixtureId ?> + '/' + <?php echo request()->leagueId ?>,
        type: 'GET',
        success: (data) => {
            $("#fixtureData").html(data)
        }
    })

    //  })
</script>











<!-- Tennis page page backUp -->

@extends('layouts/pageHead')
<style>
    td,
    td p {
        /* height: 50px; */
        vertical-align: middle;
    }
</style>
<main class="marginTopSmallNavLong" style="background-color:  #F5F5F5;">
    <div class="mx-auto m-2 wid80 wid20Mobile d-block higt125px" style="overflow: hidden;">
        <a href="{{ $bannerLong->url }}"><img src="{{ 'files/'.$bannerLong->name }}" class="wid100" alt=""></a>
    </div>
    <div class="wid80 wid100Mobile p-lg-3 bgWhite mx-auto rounded">
        <div class="d-flex flex-wrap justify-content-center">
            <div class="p-2 mx-auto order-2 order-md-0 bgSocials wid30 wid100Mobile">
                <p class="fontSize12px my-3 boldFive">Top Leagues</p>
                <div class="d-block wid100 mx-auto mb-3">
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> ATP French Open Men Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> ATP US Open Men Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> ATP Australian Open Men Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> ATP Wimbledon Men Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> WTA Wimbledon Women Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> WTA US Open Women Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> WTA French Open Women Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> WTA Australian Open Women Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> ATP Auckland,New Zealand Men Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> WTA Hobart, Australia Women Singles</a>
                    <!-- <button class="wid100 fontSize12px blackKsb bgNone borderNone p-2">See more</button> -->
                </div>
                <p class="fontSize12px my-3 boldFive">A - Z</p>
                <div class="d-block wid100 mx-auto mb-1">
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> ATP - Singles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> Challenger</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> ITF Men</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> ITF Women</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> Mixed Doubles</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> WTA</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"> WTA - Singles</a>
                </div>
                <div class="wid100 wid100Mobile mt-4 shortBannerHeight">
                    <a href="{{ $bannerShort->url }}"><img src="{{ 'files/'.$bannerShort->name }}" class="wid100 wid100Mobile" alt=""></a>
                </div>
            </div>
            <div class="p-2 order-1 order-md-1 bgWhite mx-auto wid70 wid100Mobile">
                <p class="fontSize16px my-3 boldFive">Today Free Games</p>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <thead>
                            <tr class="bgShaddyWhite">
                                <td colspan="8" class="white"><img src="{{ asset('icons/football/qater.png') }}" alt=""> Qatar ITF MEN - SINGLES: M15 DOHA, HARD</td>
                            </tr>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px centerText">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                        </thead>

                        <tbody id="basketGames">
                            <tr>
                                <td colspan="6" class="bgGrey">
                                    <div class="d-block mx-auto">
                                        <img src="{{ asset('icons/loaders/Soccerball.gif') }}" alt="" class="wid10 d-block mx-auto">
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <tbody>
                            <thead class="bgShaddyWhite">
                                <tr>
                                    <td colspan="8" class="white"><img src="{{ asset('icons/football/spain.png') }}" alt=""> ITF WOMEN - DOUBLES: W40 TALLINN, HARD</td>
                                </tr>
                            </thead>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Bobrov B.</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Colson T.</td>
                                <td class="fontSize10px">2</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Sharipov M.</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Feldbausch K.</td>
                                <td class="fontSize10px">1</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <tbody>
                            <thead class="bgShaddyWhite">
                                <tr>
                                    <td colspan="8" class="white"><img src="{{ asset('icons/football/france.png') }}" alt=""> France ITF MEN - SINGLES: M25 VEIGY-FONCENEX, HARD</td>
                                </tr>
                            </thead>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Bobrov B. </td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Colson T.</td>
                                <td class="fontSize10px">1</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Sharipov M.</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Feldbausch K.</td>
                                <td class="fontSize10px">1</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <tbody>
                            <thead class="bgShaddyWhite">
                                <tr>
                                    <td colspan="8" class="white"><img src="{{ asset('icons/football/france.png') }}" alt=""> ITF WOMEN - SINGLES: W15 FORT-DE-FRANCE, HARD</td>
                                </tr>
                            </thead>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Sultanov K.</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Visker N.</td>
                                <td class="fontSize10px">2</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="wid100 bgBlue mt-4 longBannerHeight">
                    <a href="https://clcr.me/xsOTPT"><img src="{{ asset('icons/football/longBanner.gif') }}" class="" alt=""></a>
                </div>
                <div class="mt-2">
                    <img src="{{ asset('icons/midIcon.png') }}" alt="" class="my-5">
                    <p class="fontSize14px linehigt17px boldFour">
                        Welcome to KSB - a membership-based sports prediction website where you can access accurate and detailed predictions for your favorite sports events. We focus on Football, Basketball, and Tennis, providing registered users with in-depth predictions and analysis to help them make informed betting decisions. <br><br>
                        Our website is designed to be user-friendly and easy to navigate, with a landing page that allows both registered and unregistered users to access a limited number of predictions. However, to access more detailed predictions, you'll need to register as a member.<br><br>
                        At KSB, we believe in providing our users with the most up-to-date and accurate predictions, which is why we have a dedicated team of experts who continuously analyze and research different sports events to bring you the most reliable predictions.<br><br>
                        In addition to predictions, our website also features banner placements and ads from leading sport betting brands, making it easy for you to place bets on your preferred sports events. Additionally, we have a Telegram channel where you can stay updated on the latest predictions and tips.<br><br>
                        If you're looking for a reliable and user-friendly website to help you make informed betting decisions, look no further than KSB. Join today and start reaping the benefits of our expert predictions!<br><br>
                    </p>
                    <a href="https://t.me/+qw-sNCIYYAc1MGI0" class="telegramBlue noneTextDecoration centerText d-block my-5 white fontSize16px p-2 boldSix wid100"><img src="{{ asset('icons/telegramVector.png') }}" alt=""> Click here to join telegram group</a>
                </div>
            </div>
        </div>
    </div>
</main>
@extends('layouts/footer')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
<script>
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    })

    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: '/loadTennisGames',
        type: 'GET',
        success: (data) => {
            $("#basketGames").html(data)
        }
    })
</script>


<!-- Tennis Games page 2.0 -->

@extends('layouts/pageHead')
<style>
    td,
    td p {
        /* height: 50px; */
        vertical-align: middle;
    }
</style>
<main class="marginTopSmallNavLong" style="background-color:  #F5F5F5;">
    <div class="mx-auto m-2 wid80 wid20Mobile d-block higt125px" style="overflow: hidden;">
        <a href="{{ $bannerLong->url }}"><img src="{{ 'files/'.$bannerLong->name }}" class="wid100" alt=""></a>
    </div>
    <div class="wid80 wid100Mobile p-lg-3 bgWhite mx-auto rounded">
        <div class="d-flex flex-wrap justify-content-center">
            <div class="p-2 mx-auto order-2 order-md-0 bgSocials wid30 wid100Mobile">
                <p class="fontSize12px my-3 boldFive">Top Football League Games</p>
                <div class="d-block wid100 mx-auto mb-3">
                    <a href="/" onclick="event.preventDefault(); loadGames(39);" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/england.png') }}" alt=""> England Premier</a>
                    <a href="/" onclick="event.preventDefault(); loadGames(78);" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/garmany.png') }}" alt=""> Garmany Bundesliga</a>
                    <a href="/" onclick="event.preventDefault(); loadGames(2);" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/europa.png') }}" alt=""> UEFA Champions League</a>
                    <a href="/" onclick="event.preventDefault(); loadGames(3);" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/europa.png') }}" alt=""> UEFA Europa League</a>
                    <a href="/" onclick="event.preventDefault(); loadGames(45);" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/england.png') }}" alt=""> England FA Cup</a>
                    <a href="/" onclick="event.preventDefault(); loadGames(61);" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/france.png') }}" alt=""> France League 1</a>
                    <a href="/" onclick="event.preventDefault(); loadGames(140);" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/spain.png') }}" alt=""> Spain LaLiga</a>
                    <a href="/" onclick="event.preventDefault(); loadGames(135);" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/italy.png') }}" alt=""> Italy Seria A</a>
                    <!-- <a href="/" onclick="event.preventDefault();Games(78);" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/africa.png') }}" alt=""> African Nations Cup</a> -->
                    <!-- <button class="wid100 fontSize12px blackKsb bgNone borderNone p-2">See more</button> -->
                </div>
                <p class="fontSize12px my-3 boldFive">A - Z</p>
                <div class="d-block wid100 mx-auto mb-1" id="countries">
                    <a href="DZ" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/algeria.png') }}" alt=""> Algeria</a>
                    <a href="AO" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/angola.png') }}" alt=""> Angola</a>
                    <a href="AR" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/angentina.png') }}" alt=""> Angentina</a>
                    <a href="AU" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/australia.png') }}" alt=""> Australia</a>
                    <a href="BE" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/belgium.png') }}" alt=""> Belgium</a>
                    <a href="BR" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/brazil.png') }}" alt=""> Brazil</a>
                    <a href="BG" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/bulgeria.png') }}" alt=""> Bulgeria</a>
                    <a href="CL" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/chile.png') }}" alt=""> Chile</a>
                    <a href="CR" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/costa.png') }}" alt=""> Costa Rica</a>
                    <a href="HR" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/croatia.png') }}" alt=""> Croatia</a>
                    <a href="CY" class="wid100 bodyA d-block boldFive p-2 country marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/cyprus.png') }}" alt=""> Cyprus</a>
                </div>
                <button class="wid100 fontSize12px blackKsb bgNone borderNone p-2" id="seeMore">Show more</button>
                <div class="wid100 wid100Mobile mt-4 shortBannerHeight">
                    <a href="{{ $bannerShort->url }}"><img src="{{ 'files/'.$bannerShort->name }}" class="wid100 wid100Mobile" alt=""></a>
                </div>
            </div>
            <div class="p-2 order-1 order-md-1 bgWhite mx-auto wid70 wid100Mobile">
                <p class="fontSize16px my-3 boldFive">Today Free Games</p>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <thead>
                            <tr class="bgShaddyWhite">
                                <td colspan="8" class="white"><img src="{{ asset('icons/football/qater.png') }}" alt=""> Tennis Predictions</td>
                            </tr>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tournament</td>
                                <td class="fontSize10px">Tips</td>
                                <td class="fontSize10px centerText">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                        </thead>

                        <tbody id="tennisGames">
                            <tr>
                                <td colspan="6" class="bgGrey">
                                    <div class="d-block mx-auto">
                                        <img src="{{ asset('icons/loaders/Soccerball.gif') }}" alt="" class="wid10 d-block mx-auto">
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <tbody>
                            <thead class="bgShaddyWhite">
                                <tr>
                                    <td colspan="8" class="white"><img src="{{ asset('icons/football/spain.png') }}" alt=""> ITF WOMEN - DOUBLES: W40 TALLINN, HARD</td>
                                </tr>
                            </thead>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Bobrov B.</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Colson T.</td>
                                <td class="fontSize10px">2</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Sharipov M.</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Feldbausch K.</td>
                                <td class="fontSize10px">1</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <tbody>
                            <thead class="bgShaddyWhite">
                                <tr>
                                    <td colspan="8" class="white"><img src="{{ asset('icons/football/france.png') }}" alt=""> France ITF MEN - SINGLES: M25 VEIGY-FONCENEX, HARD</td>
                                </tr>
                            </thead>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Bobrov B. </td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Colson T.</td>
                                <td class="fontSize10px">1</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Sharipov M.</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Feldbausch K.</td>
                                <td class="fontSize10px">1</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <tbody>
                            <thead class="bgShaddyWhite">
                                <tr>
                                    <td colspan="8" class="white"><img src="{{ asset('icons/football/france.png') }}" alt=""> ITF WOMEN - SINGLES: W15 FORT-DE-FRANCE, HARD</td>
                                </tr>
                            </thead>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Sultanov K.</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Visker N.</td>
                                <td class="fontSize10px">2</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="wid100 bgBlue mt-4 longBannerHeight">
                    <a href="https://clcr.me/xsOTPT"><img src="{{ asset('icons/football/longBanner.gif') }}" class="" alt=""></a>
                </div>
                <div class="mt-2">
                    <img src="{{ asset('icons/midIcon.png') }}" alt="" class="my-5">
                    <p class="fontSize14px linehigt17px boldFour">
                        Welcome to KSB - a membership-based sports prediction website where you can access accurate and detailed predictions for your favorite sports events. We focus on Football, Basketball, and Tennis, providing registered users with in-depth predictions and analysis to help them make informed betting decisions. <br><br>
                        Our website is designed to be user-friendly and easy to navigate, with a landing page that allows both registered and unregistered users to access a limited number of predictions. However, to access more detailed predictions, you'll need to register as a member.<br><br>
                        At KSB, we believe in providing our users with the most up-to-date and accurate predictions, which is why we have a dedicated team of experts who continuously analyze and research different sports events to bring you the most reliable predictions.<br><br>
                        In addition to predictions, our website also features banner placements and ads from leading sport betting brands, making it easy for you to place bets on your preferred sports events. Additionally, we have a Telegram channel where you can stay updated on the latest predictions and tips.<br><br>
                        If you're looking for a reliable and user-friendly website to help you make informed betting decisions, look no further than KSB. Join today and start reaping the benefits of our expert predictions!<br><br>
                    </p>
                    <a href="https://t.me/+qw-sNCIYYAc1MGI0" class="telegramBlue noneTextDecoration centerText d-block my-5 white fontSize16px p-2 boldSix wid100"><img src="{{ asset('icons/telegramVector.png') }}" alt=""> Click here to join telegram group</a>
                </div>
            </div>
        </div>
    </div>
</main>
@extends('layouts/footer')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
<script>
    $(document).ready(() => {
        var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
        var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl)
        })

        $("#seeMore").click(() => {
            $(this).text("Loading...")
            // $("#seeMore").text(function(i, text) {
            //     return text === "Show more" ? "Show less" : "Show more";
            // });
            $.ajax({
                url: '/loadCountries',
                type: 'GET',
                success: (data) => {
                    $("#countries").html(data)
                }
            })
        })


        Array.from(document.getElementsByClassName("country")).forEach(
            function(element, index, array) {
                element.addEventListener("click", (e) => {
                    e.preventDefault()
                    //alert(element.getAttribute("href"));
                    //  $("#bodyVal").html(element.getAttribute("href"))
                    // document.getElementById("bodyVal").innerHTML = element.getAttribute("href");
                    $.ajax({
                        url: 'loadLeagues/' + element.getAttribute("href"),
                        type: "GET",
                        success: (data) => {
                            $("#bodyVal").html(data)
                        }
                    })
                })
            }
        );

        if (localStorage.getItem('loadGamesLocal') !== null) {
            $('#tennisGames').html($('#tennisGames').data('old-state'));
        } else {
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: '/loadTennisGames',
                type: 'GET',
                success: (data) => {
                    $("#tennisGames").html(data)
                }

            })
            $('#tennisGames').data('old-state', $('#tennisGames').html());
            localStorage.setItem('loadGamesLocal', $('#tennisGames').data('old-state'));
        }
        setTimeout(function() {
            localStorage.removeItem('loadGamesLocal');
        }, 120000);
    })

    function loadGames(leagueId) {
        $("#bodyVal").html(' <div class="d-block wid60 mx-auto"><img src = "{{ asset("icons/loaders/Soccerball.gif") }}" alt = "" class ="wid10 d-block mx-auto" ><p class="centerText blackSol fontSize12px">Loading games please wait...</p></div>');
        $.ajax({
            url: '/loadLeagueGames/' + leagueId,
            type: 'GET',
            success: (data) => {
                $("#bodyVal").html(data)
            }
        })
    }
</script>