<h2>Hey, It's me {{ $data->name }}</h2>
<br>

<strong>User details: </strong><br>
<strong>Email: </strong>{{ $data->email }} <br>
<strong>Subject: </strong>{{ $data->subject }} <br>
<strong>Message: </strong>{{ $data->message }} <br><br>

Thank you