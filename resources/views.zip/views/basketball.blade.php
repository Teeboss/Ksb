@extends('layouts/pageHead')
<style>
    td,
    td p {
        /* height: 50px; */
        vertical-align: middle;
    }
</style>
<main class="marginTopSmallNavLong" style="background-color:  #F5F5F5;">
    <div class="mx-auto m-2 wid80 wid20Mobile d-block higt125px" style="overflow: hidden;">
        <a href="https://clcr.me/xsOTPT"><img src="{{ asset('icons/longBanner.gif') }}" class="wid100" alt=""></a>
    </div>
    <div class="wid80 wid100Mobile p-lg-3 bgWhite mx-auto rounded">
        <div class="d-flex flex-wrap justify-content-center">
            <div class="p-2 mx-auto order-2 order-md-0 bgSocials wid30 wid100Mobile">
                <p class="fontSize12px my-3 boldFive">Top Leagues</p>
                <div class="d-block wid100 mx-auto mb-3">
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/usa.png') }}" alt=""> USA NBA</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/spain.png') }}" alt=""> Spain Liga ACB</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/usa.png') }}" alt=""> USA WNBA</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/italy.png') }}" alt=""> Italy Seria A</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/turkey.png') }}" alt=""> Turkiye Super Lig</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/garmany.png') }}" alt=""> Garmany BBL</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/greece.png') }}" alt=""> Greece A1</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/internationalChamp.png') }}" alt=""> International EuroLeague</a>
                    <!-- <button class="wid100 fontSize12px blackKsb bgNone borderNone p-2">See more</button> -->
                </div>
                <p class="fontSize12px my-3 boldFive">A - Z</p>
                <div class="d-block wid100 mx-auto mb-1">
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/algeria.png') }}" alt=""> Algeria</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/angola.png') }}" alt=""> Angola</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/angentina.png') }}" alt=""> Angentina</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/australia.png') }}" alt=""> Australia</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/belgium.png') }}" alt=""> Belgium</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/brazil.png') }}" alt=""> Brazil</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/bulgeria.png') }}" alt=""> Bulgeria</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/chile.png') }}" alt=""> Chile</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/costa.png') }}" alt=""> Costa Rica</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/croatia.png') }}" alt=""> Croatia</a>
                    <a href="/football" class="wid100 bodyA d-block boldFive p-2 marginY fontSize12px bgWhite"><img src="{{ asset('icons/football/cyprus.png') }}" alt=""> Cyprus</a>
                    <button class="wid100 fontSize12px blackKsb bgNone borderNone p-2">See more</button>
                </div>
                <div class="wid100 wid100Mobile mt-4 shortBannerHeight">
                    <a href="https://clcr.me/xsOTPT"><img src="{{ asset('icons/shortBanner.jpg') }}" class="wid100 wid100Mobile" alt=""></a>
                </div>
            </div>
            <div class="p-2 order-1 order-md-1 bgWhite mx-auto wid70 wid100Mobile">
                <p class="fontSize16px my-3 boldFive">Today Free Games</p>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <thead>
                            <tr class="bgShaddyWhite">
                                <td colspan="8" class="white"><img src="{{ asset('icons/football/spain.png') }}" alt=""> Spain: LEB PLATA</td>
                            </tr>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                        </thead>

                        <tbody id="basketGames">
                            <tr>
                                <td colspan="6" class="bgGrey">
                                    <div class="d-block mx-auto">
                                        <img src="{{ asset('icons/loaders/Soccerball.gif') }}" alt="" class="wid10 d-block mx-auto">
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <tbody>
                            <thead class="bgShaddyWhite">
                                <tr>
                                    <td colspan="8" class="white"><img src="{{ asset('icons/football/china.png') }}" alt=""> CHINA: CBA</td>
                                </tr>
                            </thead>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Beijing Royal Fighters</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Guangdong</td>
                                <td class="fontSize10px">GG</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Eastern Long Lions</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Macau Black Bears</td>
                                <td class="fontSize10px">GG</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <tbody>
                            <thead class="bgShaddyWhite">
                                <tr>
                                    <td colspan="8" class="white"><img src="{{ asset('icons/football/russia.png') }}" alt=""> RUSSIA: PREMIER LEAGUE WOMEN</td>
                                </tr>
                            </thead>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Enisey Krasnoyarsk W </td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Nadezhda W</td>
                                <td class="fontSize10px">GG</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Novosibirsk W</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">Nika Siktivkar W</td>
                                <td class="fontSize10px">GG</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive shadow mb-4">
                    <table class="table table-hover">
                        <tbody>
                            <thead class="bgShaddyWhite">
                                <tr>
                                    <td colspan="8" class="white"><img src="{{ asset('icons/football/ukraine.png') }}" alt=""> UKRAINE: FBU SUPERLEAGUE</td>
                                </tr>
                            </thead>
                            <tr class="boldFour">
                                <td colspan="4" class="fontSize10px">Events</td>
                                <td class="fontSize10px">Tip</td>
                                <td class="fontSize10px">Odd</td>
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="fontSize10px">00:20</td>
                                <td class="fontSize10px">Goverla</td>
                                <td class="fontSize10px">vs</td>
                                <td class="fontSize10px">BC Halychyna</td>
                                <td class="fontSize10px">2</td>
                                <td class="fontSize10px">1.50</td>
                                <td colspan="2" class="fontSize10px">
                                    <div class=" wid70 mx-auto">
                                        <div class="d-flex justify-content-between">
                                            <img src="{{ asset('icons/1xbet.png') }}" alt="">
                                            <img src="{{ asset('icons/bet9ja.png') }}" alt="">
                                            <!-- <img src="{{ asset('icons/sportyBet.png') }}" alt=""> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="wid100 bgBlue mt-4 longBannerHeight">
                    <a href="https://clcr.me/xsOTPT"><img src="{{ asset('icons/football/longBanner.gif') }}" class="" alt=""></a>
                </div>
                <div class="mt-2">
                    <img src="{{ asset('icons/midIcon.png') }}" alt="" class="my-5">
                    <p class="fontSize14px linehigt17px boldFour">
                        Welcome to KSB - a membership-based sports prediction website where you can access accurate and detailed predictions for your favorite sports events. We focus on Football, Basketball, and Tennis, providing registered users with in-depth predictions and analysis to help them make informed betting decisions. <br><br>
                        Our website is designed to be user-friendly and easy to navigate, with a landing page that allows both registered and unregistered users to access a limited number of predictions. However, to access more detailed predictions, you'll need to register as a member.<br><br>
                        At KSB, we believe in providing our users with the most up-to-date and accurate predictions, which is why we have a dedicated team of experts who continuously analyze and research different sports events to bring you the most reliable predictions.<br><br>
                        In addition to predictions, our website also features banner placements and ads from leading sport betting brands, making it easy for you to place bets on your preferred sports events. Additionally, we have a Telegram channel where you can stay updated on the latest predictions and tips.<br><br>
                        If you're looking for a reliable and user-friendly website to help you make informed betting decisions, look no further than KSB. Join today and start reaping the benefits of our expert predictions!<br><br>
                    </p>
                    <a href="https://t.me/+qw-sNCIYYAc1MGI0" class="telegramBlue noneTextDecoration centerText d-block my-5 white fontSize16px p-2 boldSix wid100"><img src="{{ asset('icons/telegramVector.png') }}" alt=""> Click here to join telegram group</a>
                </div>
            </div>
        </div>
    </div>
</main>
@extends('layouts/footer')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
<script>
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    })

    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: '/loadBasketballGames',
        type: 'GET',
        success: (data) => {
            $("#basketGames").html(data)
        }
    })
</script>