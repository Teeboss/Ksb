@extends('layouts/pageHead')
<main class="marginTopSmallNavLong" style="background-color:  #F5F5F5;">
    <?php //echo request()->leagueId;"\n" 
    ?>
    <?php // echo date("Y", strtotime("-1 year")); 
    ?>
    <div class="mx-auto m-2 wid80 wid20Mobile d-block higt125px" style="overflow: hidden;">
        <img src="{{ asset('icons/1xbanner.png') }}" class="wid100" alt="">
    </div>
    <div class="d-block p-2 p-sm-0 mx-auto wid100Mobile wid60 bgWhite" id="fixtureData">
        <div class="d-block mx-auto wid80">
            <img src="{{ asset('icons/loaders/Soccerball.gif') }}" alt="" class="wid10 d-block mx-auto">
        </div>
    </div>
    <div class="mx-auto m-0 wid60 wid20Mobile d-block higt125px" style="overflow: hidden;">
        <img src="{{ asset('icons/1xbanner.png') }}" class="wid100" alt="">
    </div>
    <div class="wid60 wid20Mobile d-block mx-auto">
        <div id="wg-api-football-standings" data-host="v3.football.api-sports.io" data-key="cf407809f5msh505bdf08a7507a5p193ce9jsn3b67bae95d39" data-league="<?php echo request()->leagueId; ?>" data-team="" data-season="<?php echo date('Y', strtotime("-1 year")); ?>" data-theme="" data-show-errors="false" data-show-logos="true" class="wg_loader">
        </div>
    </div>
</main>
@extends('layouts/footer')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.js" integrity="sha512-CX7sDOp7UTAq+i1FYIlf9Uo27x4os+kGeoT7rgwvY+4dmjqV0IuE/Bl5hVsjnQPQiTOhAX1O2r2j5bjsFBvv/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
<script type="module" src="https://widgets.api-sports.io/2.0.3/widgets.js"></script>
<script>
    $(document).ready(function() {
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: '/loadFixture/' + <?php echo request()->fixtureId ?> + '/' + <?php echo request()->leagueId ?>,
            type: 'GET',
            success: (data) => {
                $("#fixtureData").html(data)
            }
        })
    })
</script>